# Phase-3 Deliverable — Baselines & Failure Analysis

**Project:** TrustFin-SLM — Trustworthy Small Language Models for Financial Tasks
**Phase:** 3 (full run) · **Status:** `PHASE-3 STATUS: PASS` · **Freeze status: `FROZEN`**
**Frozen backbone (Phase-4):** **E5** — `Qwen/Qwen3-1.7B` + balanced joint QLoRA

This bundle contains the Phase-3 full-run outputs needed to review, reproduce, and build on the
frozen baseline. **LoRA adapters (`checkpoints/`) are intentionally excluded** to keep the bundle
small; the frozen E5 adapter lives in `artifacts/phase3/checkpoints/E5` in the main workspace.

---

## Contents

```
Phase3_TrustFin_Deliverable/
├── README.md                          # full project README (phase index, datasets, policy)
├── PHASE3_RUN_NOTES.md                # how the run was sharded/executed; reproduce steps
├── DELIVERABLE_README.md              # this file
├── docs/
│   ├── exp_3(a).md                    # Phase-3 SMOKE run — deep explanation
│   ├── exp_3(b).md                    # Phase-3 FULL  run — deep explanation (results)
│   └── RESUME_phase3_2026-10-10.md    # mid-run checkpoint note (run now complete)
├── notebooks/
│   ├── Phase3_TrustFin_SLM_Baselines_and_Failure_Analysis.ipynb   # master (executed, 36 cells)
│   ├── Phase3_full_E1.ipynb           # executed per-part run notebooks (8 parts)
│   ├── Phase3_full_E7.ipynb
│   ├── Phase3_full_E4.ipynb
│   ├── Phase3_full_E5.ipynb
│   ├── Phase3_full_E8.ipynb
│   ├── Phase3_full_E11.ipynb
│   ├── Phase3_full_E9.ipynb
│   ├── Phase3_full_E12.ipynb          # E12–E16 + freeze gates
│   ├── Phase3_smoke_run3.ipynb
│   └── Phase3_smoke_executed.ipynb
├── artifacts/phase3/
│   ├── metrics/                       # E1–E16 metrics + *_training.json + validation CSV
│   ├── analysis/                      # E9–E16 ablations, failure, confidence, efficiency
│   ├── plots/                         # finqa_execution_accuracy.png, fiqa_mae.png
│   ├── predictions/                   # per-record model outputs (E1–E11 + ablations)
│   └── manifests/                     # phase3_freeze.json, environment.json, plan, gates
└── logs/                              # nbconvert per-part logs + supervisor output
```

## Frozen contract (Phase-4 handoff)

From `artifacts/phase3/manifests/phase3_freeze.json`:

| Item | Value |
|---|---|
| Backbone | `E5` — `Qwen/Qwen3-1.7B`, balanced joint QLoRA |
| FinQA prompt | `canonical` |
| FiQA prompt | `explicit_schema` |
| Selection | validation-only; `JOINT_CANDIDATES = {E5, E11}` |
| Protected sets | untouched — no protected test set was used for selection |

## Phase-3 headline results (validation only, n = 883 FinQA + 117 FiQA)

| Experiment | Model | Sampling | FinQA exec | FinQA prog | FiQA MAE | FiQA R² |
|---|---|---|---|---|---|---|
| **E5** ⭐ | Qwen3-1.7B | balanced joint | **0.675** | 0.612 | 0.130 | 0.730 |
| E11 | Qwen3-1.7B | natural joint | 0.615 | 0.555 | 0.128 | 0.736 |
| E8 | Phi-4-mini | balanced joint | 0.701 | 0.640 | 0.130 | 0.809 |

Prompt policy: FinQA → `canonical`; FiQA → `explicit_schema`.

## Reproduce

```bash
cd "/home/heet18/Downloads/Research Papers"
# full run (sharded) — see PHASE3_RUN_NOTES.md
bash tools/phase3_supervisor.sh
# or verification only
.venv/bin/python tools/phase3_shard.py verify
```

Full methodology, all 16 experiments, ablations, and failure analysis: **`docs/exp_3(b).md`**.
